WITH historico_sem_duplicidade AS (
    SELECT
        p.NUMR_PROCESSO_DIVIDA_ATIVA AS numr_processo,
        p.CODG_DIVISAO AS codg_orgao_origem,
        h.DATA_ATUALZ_HISTORICO AS data_atualizacao,
        h.VALR_ATUALIZADO AS valor_total_atualizado,
        ROW_NUMBER() OVER (
            PARTITION BY
                p.ID_PROCESSO_DIVIDA_ATIVA,
                TO_CHAR(h.DATA_ATUALZ_HISTORICO, 'YYYYMM')
            ORDER BY
                h.DATA_ATUALZ_HISTORICO DESC,
                h.ID_HISTORICO_VALOR_PROCESSO DESC
        ) AS rn
    FROM SDA.SDA_PROCESSO_DIVIDA_ATIVA p
    INNER JOIN SDA.SDA_HISTORICO_VALOR_PROCESSO h
        ON h.ID_PROCESSO_DIVIDA_ATIVA = p.ID_PROCESSO_DIVIDA_ATIVA
)
SELECT
    numr_processo,
    codg_orgao_origem,
    TO_CHAR(data_atualizacao, 'DD/MM/YYYY') AS data_atualizacao,
    valor_total_atualizado
FROM historico_sem_duplicidade
WHERE rn = 1
ORDER BY
    numr_processo,
    data_atualizacao;
